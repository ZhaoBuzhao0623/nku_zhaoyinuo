#pragma once
class vector
{
};

